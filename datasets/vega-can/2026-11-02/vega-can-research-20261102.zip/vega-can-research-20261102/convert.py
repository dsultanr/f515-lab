#!/usr/bin/env python3
"""Offline Vega RX binary -> CSV and candump. Python 3.8+, no dependencies."""
import csv, json, struct, sys, zlib
from pathlib import Path
from collections import Counter, defaultdict

def read_records(path):
    data=Path(path).read_bytes();off=0;records=[];controls=Counter()
    while off<len(data):
        if off+7>len(data):raise ValueError(f'Incomplete header at {off}')
        size=struct.unpack_from('<H',data,off)[0]+7
        frame=data[off:off+size]
        if len(frame)!=size:raise ValueError(f'Incomplete packet at {off}')
        if zlib.crc32(frame[:-4])!=struct.unpack_from('<I',frame,size-4)[0]:raise ValueError(f'CRC mismatch at {off}')
        if frame[2]==0x1e:
            if size<16 or size!=16+18*frame[3]:raise ValueError(f'Invalid CAN count at {off}')
            for i in range(frame[3]):
                at=12+i*18;t,cid,bus,dlc=struct.unpack_from('<IIBB',frame,at)
                if dlc>8:raise ValueError(f'Invalid DLC at {off}')
                records.append((t,cid,bus,dlc,frame[at+10:at+18]))
        else:controls[frame[2]]+=1
        off+=size
    return records,controls

def write_csv(path,header,rows):
    with Path(path).open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)

def convert(source,destination):
    out=Path(destination);out.mkdir(parents=True,exist_ok=True)
    records,controls=read_records(source)
    origin=min(r[0] for r in records)
    # This recording has no 32-bit timer rollover. Do not silently unwrap future recordings.
    if max(r[0] for r in records)-origin>2**31:raise ValueError('Possible timer rollover: manual treatment required')
    write_csv(out/'frames.csv',['seq','tracker_ms','relative_ms','bus_raw','can_id_hex','dlc','data_hex','storage_8_hex'],
              ((seq,t,t-origin,bus,f'0x{cid:X}',dlc,payload[:dlc].hex().upper(),payload.hex().upper())
               for seq,(t,cid,bus,dlc,payload) in enumerate(records)))
    ordered=sorted(enumerate(records),key=lambda pair:(pair[1][0],pair[0]))
    with (out/'candump.log').open('w',encoding='ascii') as f:
        for seq,(t,cid,bus,dlc,payload) in ordered:
            if cid>0x7ff:raise ValueError('Extended-ID flags need explicit interpretation')
            rel=t-origin
            f.write(f'({rel//1000}.{rel%1000:03d}000) can{bus} {cid:03X}#{payload[:dlc].hex().upper()}\n')
    stats=defaultdict(list)
    for t,cid,bus,dlc,payload in records:stats[bus,cid].append(t)
    write_csv(out/'id_summary.csv',['bus_raw','can_id_hex','frames','first_relative_ms','last_relative_ms'],
              ((bus,f'0x{cid:X}',len(times),min(times)-origin,max(times)-origin) for (bus,cid),times in sorted(stats.items())))
    times=sorted(set(r[0] for r in records));gaps=[(a-origin,b-origin,b-a) for a,b in zip(times,times[1:]) if b-a>100]
    write_csv(out/'gaps_over_100ms.csv',['previous_relative_ms','next_relative_ms','gap_ms'],gaps)
    result={'frames':len(records),'buses':dict(Counter(r[2] for r in records)),'unique_bus_id_pairs':len(stats),
            'first_tracker_ms':origin,'last_tracker_ms':times[-1],'can_span_ms':times[-1]-origin,
            'control_packets':dict(controls),'gaps_over_100ms':len(gaps),'max_gap_ms':max(g[2] for g in gaps),
            'receive_order_timestamp_regressions':sum(b[0]<a[0] for a,b in zip(records,records[1:]))}
    (out/'can_statistics.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: python3 convert.py RAW.bin OUTPUT_DIRECTORY')
    print(json.dumps(convert(sys.argv[1],sys.argv[2]),indent=2))
