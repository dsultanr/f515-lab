package su.dsr.vega.monitor;

import android.hardware.usb.*;
import su.dsr.vega.monitor.core.Transport;
import java.io.IOException;

/** Exclusive userspace CDC ACM owner. No tty paths or elevated privileges. */
public final class UsbTransport implements Transport {
    public static final int VID = 0x28e9, PID = 0x018a;
    private volatile UsbDeviceConnection connection;
    private final UsbInterface control, data;
    private final UsbEndpoint input, output;
    private final String identity;
    public static boolean isVega(UsbDevice device) { return device != null && device.getVendorId() == VID && device.getProductId() == PID; }
    public UsbTransport(UsbManager manager, UsbDevice device) throws IOException {
        if (!isVega(device) || !manager.hasPermission(device)) throw new IOException("USB permission required");
        identity = device.getDeviceName(); // Ephemeral root capture; no saved device credentials.
        UsbInterface c = null, d = null; UsbEndpoint in = null, out = null;
        for (int i=0; i<device.getInterfaceCount(); i++) {
            UsbInterface face = device.getInterface(i);
            if (face.getInterfaceClass() == UsbConstants.USB_CLASS_COMM) c = face;
            if (face.getInterfaceClass() == UsbConstants.USB_CLASS_CDC_DATA) {
                UsbEndpoint a = null, b = null;
                for (int j=0; j<face.getEndpointCount(); j++) {
                    UsbEndpoint ep = face.getEndpoint(j);
                    if (ep.getType() != UsbConstants.USB_ENDPOINT_XFER_BULK) continue;
                    if (ep.getDirection() == UsbConstants.USB_DIR_IN) a = ep; else b = ep;
                }
                if (a != null && b != null) { d=face; in=a; out=b; }
            }
        }
        if (c == null || d == null) throw new IOException("CDC ACM interfaces unavailable");
        control=c; data=d; input=in; output=out;
        connection=manager.openDevice(device);
        if (connection == null) throw new IOException("Cannot open USB device");
        try {
            if (!connection.claimInterface(control,true) || !connection.claimInterface(data,true)) throw new IOException("Cannot claim CDC interfaces");
            byte[] coding = {0x00,(byte)0xc2,0x01,0x00,0x00,0x00,0x08};
            if (connection.controlTransfer(0x21,0x20,0,control.getId(),coding,7,1000) != 7) throw new IOException("CDC line coding failed");
            if (connection.controlTransfer(0x21,0x22,3,control.getId(),null,0,1000) < 0) throw new IOException("CDC DTR/RTS failed");
        } catch (IOException e) { close(); throw e; }
    }
    @Override public int read(byte[] buffer, int timeoutMs) throws IOException {
        UsbDeviceConnection c=connection; if(c==null) throw new IOException("USB closed");
        int n=c.bulkTransfer(input,buffer,buffer.length,Math.max(1,timeoutMs));
        if(connection==null) throw new IOException("USB closed");
        // Android bulkTransfer uses -1 for both timeout and transport errors; session timeout/reconnect handles it.
        return n < 0 ? 0 : n;
    }
    @Override public void write(byte[] bytes,int timeoutMs) throws IOException {
        UsbDeviceConnection c=connection; if(c==null) throw new IOException("USB closed");
        int offset=0;
        while(offset<bytes.length) {
            int n=c.bulkTransfer(output,bytes,offset,bytes.length-offset,Math.max(1,timeoutMs));
            if(n<=0 || connection==null) throw new IOException("USB write failed");
            offset+=n;
        }
    }
    @Override public String identity() { return identity; }
    @Override public synchronized void close() {
        UsbDeviceConnection c=connection; connection=null;
        if(c!=null) { try { c.releaseInterface(data); c.releaseInterface(control); } finally { c.close(); } }
    }
}
