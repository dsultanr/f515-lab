from pathlib import Path
import subprocess,os,zipfile
root=Path(__file__).parent
base=Path('/home/dsultanr/f515/f515-vega-monitor/src/su/dsr/vega/monitor')
android='/home/dsultanr/android-sdk/android-11/android.jar'
jdk='/home/dsultanr/jdk/bin'
sources=[root/'HeadlessCan.java',root/'UsbTransport.java']+[base/'core'/x for x in ['Transport.java','VegaClient.java','CanStreamPacket.java','PasswordCandidates.java']]
subprocess.run([jdk+'/javac','--release','8','-classpath',android,'-d',str(root/'classes')]+list(map(str,sources)),check=True)
env=dict(os.environ,PATH=jdk+':'+os.environ['PATH'])
subprocess.run(['/home/dsultanr/android-sdk/android-14/d8','--min-api','30','--lib',android,'--output',str(root/'dex')]+list(map(str,(root/'classes').rglob('*.class'))),env=env,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
with zipfile.ZipFile(root/'headless-can.jar','w',zipfile.ZIP_DEFLATED) as z:z.write(root/'dex/classes.dex','classes.dex')
print('Build OK')
