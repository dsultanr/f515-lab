package su.dsr.vega.capture;

import android.os.SystemClock;
import android.os.Looper;
import android.content.Context;
import android.hardware.usb.*;
import su.dsr.vega.monitor.UsbTransport;
import android.system.*;
import java.io.*;
import java.nio.channels.FileLock;
import java.util.*;
import org.json.JSONObject;
import su.dsr.vega.monitor.core.*;

/** Standalone passive capture. No Activity, service, vehicle commands or configuration writes. */
public final class HeadlessCan {
    static long frames,packets,startedWall,startedElapsed,rearms;
    static int duration,remoteState=-1;
    static long rawBytes,lastRxWall,lastRxElapsed,rearmElapsed;
    static String wakeName="vega_can_capture_20261103";
    static void wake(boolean acquire,int seconds)throws IOException{
        try(FileOutputStream f=new FileOutputStream(acquire?"/sys/power/wake_lock":"/sys/power/wake_unlock")){
            f.write((wakeName+(acquire?" "+(seconds*1000000000L):"")).getBytes("UTF-8"));
        }
    }
    static final Map<Integer,Long> buses=new TreeMap<>();
    static final Set<String> ids=new HashSet<>();
    static void accept(byte[] frame){
        if(frame==null)return;
        CanStreamPacket packet=CanStreamPacket.decode(frame);
        if(packet==null)return;packets++;
        for(CanStreamPacket.Record r:packet.getRecords()){
            frames++;buses.put(r.bus,buses.getOrDefault(r.bus,0L)+1);ids.add(r.bus+":"+r.canId);
        }
    }
    static void status(File dir,String state,VegaClient client,String error)throws Exception {
        JSONObject busCounts=new JSONObject();for(Map.Entry<Integer,Long> e:buses.entrySet())busCounts.put(e.getKey().toString(),e.getValue());
        JSONObject j=new JSONObject().put("state",state).put("duration_sec",duration).put("started_ms",startedWall)
          .put("started_elapsed_ms",startedElapsed).put("status_wall_ms",System.currentTimeMillis()).put("elapsed_ms",startedElapsed==0?0:SystemClock.elapsedRealtime()-startedElapsed).put("bytes",new File(dir,"stream.bin").length())
          .put("frames",frames).put("packets",packets).put("buses",busCounts).put("unique_ids",ids.size())
          .put("rearms",rearms).put("rearm_elapsed_ms",rearmElapsed).put("last_rx_wall_ms",lastRxWall).put("last_rx_elapsed_ms",lastRxElapsed).put("raw_bytes",rawBytes).put("remote_state_before",remoteState).put("dropped_bytes",client==null?0:client.canDroppedBytes());
        if(error!=null)j.put("error",error);
        File tmp=new File(dir,"status.json.tmp");
        try(FileOutputStream out=new FileOutputStream(tmp)){out.write(j.toString().getBytes("UTF-8"));out.getFD().sync();}
        if(!tmp.renameTo(new File(dir,"status.json")))throw new IOException("Status rename failed");
        System.out.println(j);System.out.flush();
    }
    public static void main(String[] args)throws Exception {
        if(android.os.Process.myUid()!=0||args.length!=2)throw new IllegalArgumentException("Root, duration, output directory required");
        duration=Integer.parseInt(args[0]);if(duration<1||duration>1800)throw new IllegalArgumentException("Duration 1..1800 seconds");
        File dir=new File(args[1]);if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Output directory unavailable");
        if(new File(dir,"stream.bin").exists())throw new IOException("Capture already exists");
        if(dir.getUsableSpace()<256L*1024*1024)throw new IOException("Insufficient free space");
        try(RandomAccessFile lockFile=new RandomAccessFile("/data/local/tmp/vega-headless-capture.lock","rw");
            FileLock lock=lockFile.getChannel().tryLock()){
            if(lock==null)throw new IOException("Another headless capture is running");
            if(Looper.myLooper()==null)Looper.prepareMainLooper();
            Class<?> at=Class.forName("android.app.ActivityThread");
            Object thread=at.getMethod("systemMain").invoke(null);
            Context context=(Context)at.getMethod("getSystemContext").invoke(thread);
            java.lang.reflect.Field systemThread=at.getDeclaredField("mSystemThread");systemThread.setAccessible(true);systemThread.setBoolean(thread,false);
            UsbManager usb=(UsbManager)context.getSystemService(Context.USB_SERVICE);
            UsbDevice device=null;
            for(UsbDevice d:usb.getDeviceList().values())if(UsbTransport.isVega(d)){
                if(device!=null)throw new IOException("Multiple Vega devices");device=d;
            }
            if(device==null)throw new IOException("Vega USB not found");
            if(!usb.hasPermission(device))UsbManager.class.getMethod("grantPermission",UsbDevice.class,int.class).invoke(usb,device,android.os.Process.myUid());
            try(VegaClient client=new VegaClient(new UsbTransport(usb,device))){
                boolean authorized=false;
                for(String candidate:PasswordCandidates.forConnection(null,null)){
                    VegaClient.AuthResult auth=client.authenticate(candidate,1800);
                    if(auth==VegaClient.AuthResult.ACCEPTED){authorized=true;break;}
                    if(auth==VegaClient.AuthResult.TIMEOUT)throw new IOException("Authentication timeout; no retry");
                }
                if(!authorized)throw new IOException("Known authentication candidates rejected");
                byte[] remote=client.readSensor(2805,1500);if(remote!=null&&remote.length>0)remoteState=remote[0]&255;
                String failure=null;
                try(FileOutputStream file=new FileOutputStream(new File(dir,"stream.bin"));BufferedOutputStream raw=new BufferedOutputStream(file,65536);
                    FileOutputStream timingFile=new FileOutputStream(new File(dir,"rx_timing.csv"));BufferedWriter timing=new BufferedWriter(new OutputStreamWriter(timingFile,"UTF-8"),65536)){
                    timing.write("offset,length,hu_wall_ms,hu_elapsed_ms\n");
                    wakeName="vega_can_capture_20261103_"+android.os.Process.myPid();
                    wake(true,duration+30);
                    startedWall=System.currentTimeMillis();startedElapsed=SystemClock.elapsedRealtime();
                    long deadline=startedElapsed+duration*1000L,lastCheckpoint=0,lastRearm=0;
                    try{
                        client.beginCanStream((b,o,n)->{
                            lastRxWall=System.currentTimeMillis();lastRxElapsed=SystemClock.elapsedRealtime();
                            timing.write(rawBytes+","+n+","+lastRxWall+","+lastRxElapsed+"\n");
                            raw.write(b,o,n);rawBytes+=n;
                        },1000);
                        while(SystemClock.elapsedRealtime()<deadline&&!new File(dir,"stop").exists()){
                            accept(client.readCanStreamFrame(250));
                            long now=SystemClock.elapsedRealtime();
                            if(System.nanoTime()-client.lastCanReceiveNanos()>2000000000L&&now-lastRearm>=3000){client.rearmCanStream(500);lastRearm=now;rearmElapsed=now-startedElapsed;rearms++;}
                            if(now-lastCheckpoint>=1000){
                                raw.flush();file.getFD().sync();timing.flush();timingFile.getFD().sync();status(dir,"running",client,null);lastCheckpoint=now;
                                if(dir.getUsableSpace()<64L*1024*1024||file.getChannel().size()>2L*1024*1024*1024)throw new IOException("Storage limit");
                            }
                        }
                        byte[] f;while((f=client.readBufferedCanStreamFrame())!=null)accept(f);
                    }catch(Exception e){failure=e.getClass().getSimpleName()+": "+e.getMessage();}
                    finally{try{client.endCanStream(500);}catch(Exception e){failure="STOP failed: "+e.getClass().getSimpleName();}raw.flush();file.getFD().sync();timing.flush();timingFile.getFD().sync();try{wake(false,0);}catch(Exception ignored){}}
                }
                status(dir,failure==null?"completed":"error",client,failure);
                if(failure!=null)System.exit(1);
            }
        }
    }
}
