from pathlib import Path
import csv,json,hashlib,struct,zlib,statistics,datetime
from collections import Counter
ROOT=Path(__file__).resolve().parent.parent
src=ROOT/'full-charge'
status=json.loads((src/'status.json').read_text())
assert status['state']=='completed',status
raw=(src/'stream.bin').read_bytes()
assert len(raw)==status['bytes']==status['raw_bytes']
chunks=[];pos=0;previous=None;jumps=[]
with (src/'rx_timing.csv').open() as f:
 for row in csv.DictReader(f):
  r={k:int(v) for k,v in row.items()}
  assert r['offset']==pos and r['length']>0
  pos+=r['length'];chunks.append(r)
  if previous:
   assert r['hu_elapsed_ms']>=previous['hu_elapsed_ms']
   change=(r['hu_wall_ms']-r['hu_elapsed_ms'])-(previous['hu_wall_ms']-previous['hu_elapsed_ms'])
   if abs(change)>100:jumps.append({'offset':r['offset'],'hu_wall_ms':r['hu_wall_ms'],'hu_elapsed_ms':r['hu_elapsed_ms'],'adjustment_ms':change})
  previous=r
assert pos==len(raw),'RX index does not cover all raw bytes'
off=0;chunk=0;n=0;packets=0;controls=Counter();buses=Counter();ids=set();times=[];offsets=[];rows=[]
while off<len(raw):
 assert off+7<=len(raw),'Incomplete header'
 size=struct.unpack_from('<H',raw,off)[0]+7
 frame=raw[off:off+size]
 assert len(frame)==size and zlib.crc32(frame[:-4])==struct.unpack_from('<I',frame,size-4)[0],f'Packet integrity failure at {off}'
 while chunks[chunk]['offset']+chunks[chunk]['length']<off+size:chunk+=1
 rx=chunks[chunk]
 if frame[2]==0x1e:
  assert size==16+18*frame[3]
  packet_times=[]
  for i in range(frame[3]):
   at=12+i*18;t,cid,bus,dlc=struct.unpack_from('<IIBB',frame,at)
   assert dlc<=8 and bus in (0,1,2)
   n+=1;buses[bus]+=1;ids.add((bus,cid));times.append(t);packet_times.append(t)
  packets+=1
  if packet_times:
   newest=max(packet_times);delta=rx['hu_elapsed_ms']-newest;offsets.append(delta)
   rows.append([off,size,min(packet_times),newest,rx['hu_wall_ms'],rx['hu_elapsed_ms'],delta])
 else:controls[frame[2]]+=1
 off+=size
assert n==status['frames'] and packets==status['packets']
assert dict(buses)=={int(k):v for k,v in status['buses'].items()}
assert len(ids)==status['unique_ids'] and status['dropped_bytes']==0
ordered=sorted(set(times));gaps=[b-a for a,b in zip(ordered,ordered[1:])]
assert ordered[-1]-ordered[0]<2**31,'Possible tracker clock rollover'
with (src/'packet_rx_timing.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['raw_offset','raw_length','first_tracker_ms','last_tracker_ms','hu_wall_ms','hu_elapsed_ms','elapsed_minus_tracker_ms']);w.writerows(rows)
checks=[json.loads(line) for line in (src/'runner.log').read_text().splitlines() if line.startswith('{')]
check_gaps=[b['elapsed_ms']-a['elapsed_ms'] for a,b in zip(checks,checks[1:])]
result={'verified':True,'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'frames':n,'can_packets':packets,'control_packets':dict(controls),'buses':dict(buses),'unique_bus_id_pairs':len(ids),'first_tracker_ms':ordered[0],'last_tracker_ms':ordered[-1],'can_span_ms':ordered[-1]-ordered[0],'gaps_over_100ms':sum(g>100 for g in gaps),'max_can_gap_ms':max(gaps,default=0),'rx_timing_rows':len(chunks),'indexed_bytes':pos,'clock_adjustments_over_100ms':jumps,'elapsed_minus_tracker_ms_min':min(offsets),'elapsed_minus_tracker_ms_median':statistics.median(offsets),'elapsed_minus_tracker_ms_max':max(offsets),'max_checkpoint_gap_ms':max(check_gaps,default=0),'rearms':status['rearms'],'dropped_bytes':status['dropped_bytes'],'clock_note':'HU wall time was adjusted. elapsedRealtime is monotonic. Packet RX times include USB delivery delay and must not be treated as exact CAN transmission time.'}
(src/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='clock_adjustments_over_100ms'},indent=2));print('Clock adjustments:',len(jumps))
